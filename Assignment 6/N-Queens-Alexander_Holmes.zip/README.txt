Programmer: Alexander Holmes
4/13/24
CS 4310: Design and Analysis of Algorithms
Assignment 6: N-Queens problem


The N-Queens Problem is the problem of placing N chess queens on an NxN chessboard so that no two queens attack each other.

The Queen comes from the game of chess. Having the ability to move up, down, and diagonal one space in any direction that still
remains available on the board (can't go off of the board)

backtracking_n_queens() - The backtracking function used to grant solutions to N-Queens

In this program we are appending solutions to a solutions list and checking to make
sure that we aren't appending reflections or rotations of correct solutions


Running with python interpreter 3.11.9 64-bit in Vscode IDE
use command python3 ./N-Queens.py or run in favorite IDE

